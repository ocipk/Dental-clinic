// Mock Data

export const services = [
  {
    id: 1,
    nameAr: "تجميل الأسنان",
    descriptionAr: "ابتسامة هوليوود، تبييض الأسنان بالليزر، وقشور الفينير الخزفية للحصول على ابتسامة أحلامك.",
    icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>'
  },
  {
    id: 2,
    nameAr: "تقويم الأسنان",
    descriptionAr: "علاج اعوجاج الأسنان باستخدام أحدث التقنيات مثل التقويم الشفاف (الإنفزلاين) والتقويم المعدني.",
    icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>'
  },
  {
    id: 3,
    nameAr: "زراعة الأسنان",
    descriptionAr: "استبدال الأسنان المفقودة باستخدام غرسات التيتانيوم الدقيقة لتعويض الوظيفة والمظهر الطبيعي.",
    icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>'
  },
  {
    id: 4,
    nameAr: "علاج الجذور والعصب",
    descriptionAr: "علاج آلام العصب بالتقنيات الحديثة وبأجهزة متطورة تضمن الراحة التامة للمريض بدون ألم.",
    icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 3.86-1.14c3.23-.73 5.43-1.8 6.14-2.51l-5-5c-.7 1.1-1.78 3.91-2.51 6.14A22 22 0 0 1 12 15Z"/><path d="m9 18 3-3a22 22 0 0 0 1.14-3.86c.73-3.23 1.8-5.43 2.51-6.14l5 5c-1.1.7-3.91 1.78-6.14 2.51A22 22 0 0 0 12 15Z"/></svg>'
  },
  {
    id: 5,
    nameAr: "طب أسنان الأطفال",
    descriptionAr: "رعاية وقائية وعلاجية مخصصة للأطفال في بيئة صديقة ومريحة لكسر حاجز الخوف من طبيب الأسنان.",
    icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>'
  },
  {
    id: 6,
    nameAr: "جراحة الفم والفكين",
    descriptionAr: "خلع ضرس العقل المطمور والجراحات الصغرى باستخدام أجهزة دقيقة وتقنيات ليزر متطورة.",
    icon: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15.5 15.5 5.5 5.5"/><path d="M4 11V9a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2"/><path d="M4 11v4c0 1.1.9 2 2 2"/><path d="M20 11v4c0 1.1-.9 2-2 2"/><path d="M10 20v-5c0-1.1.9-2 2-2h4c1.1 0 2 .9 2 2v5"/><path d="M14 2v4"/><path d="M10 2v4"/></svg>'
  }
];

export const doctors = [
  {
    id: 1,
    nameAr: "د. أحمد عبدالله",
    specializationAr: "استشاري زراعة وتجميل الأسنان",
    image: "https://i.pravatar.cc/300?img=11",
    experienceYears: 15,
    bioAr: "حاصل على البورد الأمريكي في زراعة الأسنان، متخصص في الحالات المعقدة لتجميل وزراعة الأسنان وتأهيل الفم الشامل."
  },
  {
    id: 2,
    nameAr: "د. سارة خالد",
    specializationAr: "أخصائية تقويم الأسنان",
    image: "https://i.pravatar.cc/300?img=5",
    experienceYears: 10,
    bioAr: "متخصصة في تقويم الأسنان الشفاف (الإنفزلاين) والتقويم المعدني باستخدام أحدث التقنيات لعلاج الأطفال والبالغين."
  },
  {
    id: 3,
    nameAr: "د. محمد العمر",
    specializationAr: "أخصائي علاج الجذور والعصب",
    image: "https://i.pravatar.cc/300?img=12",
    experienceYears: 8,
    bioAr: "دقة عالية في علاج الجذور والعصب باستخدام الميكروسكوب الجراحي لضمان أفضل النتائج والحفاظ على الأسنان الطبيعية."
  },
  {
    id: 4,
    nameAr: "د. نورة سالم",
    specializationAr: "أخصائية طب أسنان الأطفال",
    image: "https://i.pravatar.cc/300?img=9",
    experienceYears: 7,
    bioAr: "خبرة في التعامل مع الأطفال وعلاج أسنانهم باستخدام تقنيات حديثة تقلل من الألم والخوف لضمان تجربة إيجابية."
  }
];

export function useGetServices() {
  return {
    data: services,
    isLoading: false,
    error: null,
  };
}

export function useGetDoctors() {
  return {
    data: doctors,
    isLoading: false,
    error: null,
  };
}

export function useCreateAppointment() {
  const mutation = {
    mutate: (data: any, options?: any) => {
      console.log('Mock appointment created', data);
      setTimeout(() => {
        options?.onSuccess?.(data);
      }, 1000);
    },
    isPending: false,
  };
  return { mutate: mutation.mutate, isPending: mutation.isPending };
}

export function useSendContactMessage() {
  const mutation = {
    mutate: (data: any, options?: any) => {
      console.log('Mock contact message sent', data);
      setTimeout(() => {
        options?.onSuccess?.(data);
      }, 1000);
    },
    isPending: false,
  };
  return { mutate: mutation.mutate, isPending: mutation.isPending };
}
