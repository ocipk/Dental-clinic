import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowLeft, CheckCircle2, Calendar, Star, ShieldCheck, Clock, Users, Phone } from "lucide-react";
import { useGetServices, useGetDoctors } from "@workspace/api-client-react";

export default function Home() {
  const { data: services } = useGetServices();
  const { data: doctors } = useGetDoctors();

  const previewServices = services?.slice(0, 3) || [];
  const previewDoctors = doctors?.slice(0, 4) || [];

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center pt-10 pb-20 overflow-hidden">
        {/* Background with overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
            alt="Dental Clinic" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/80 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="max-w-2xl"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-bold text-sm mb-6 border border-primary/20">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
                </span>
                العيادة الأولى لطب وتقويم الأسنان
              </div>
              
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-display font-extrabold text-foreground leading-[1.1] mb-6">
                ابتسامتك تستحق <br />
                <span className="text-gradient">أفضل رعاية</span>
              </h1>
              
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed max-w-xl">
                نقدم أحدث التقنيات وأفضل الخبرات الطبية لنمنحك ابتسامة صحية وجذابة. فريقنا المتميز يضمن لك تجربة علاجية مريحة وبدون ألم.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link 
                  href="/booking" 
                  className="px-8 py-4 rounded-2xl font-bold bg-primary text-white shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-1 transition-all duration-300 text-center flex items-center justify-center gap-2 text-lg"
                >
                  <Calendar className="w-5 h-5" />
                  احجز موعدك الآن
                </Link>
                <Link 
                  href="/services" 
                  className="px-8 py-4 rounded-2xl font-bold bg-white text-foreground border-2 border-border hover:border-primary/50 hover:bg-primary/5 transition-all duration-300 text-center flex items-center justify-center gap-2 text-lg"
                >
                  تصفح خدماتنا
                </Link>
              </div>

              <div className="mt-12 flex items-center gap-6">
                <div className="flex -space-x-4 rtl:space-x-reverse">
                  {[1, 2, 3, 4].map((i) => (
                    <img key={i} src={`https://i.pravatar.cc/100?img=${i + 10}`} alt="Patient" className="w-12 h-12 rounded-full border-2 border-white shadow-sm" />
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-1 text-amber-400 mb-1">
                    {[1, 2, 3, 4, 5].map((i) => <Star key={i} className="w-4 h-4 fill-current" />)}
                  </div>
                  <p className="text-sm font-bold text-foreground">+5000 مريض سعيد</p>
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden lg:block relative"
            >
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-gradient-to-tr from-primary/20 to-accent/20 blur-3xl rounded-full -z-10"></div>
              
              {/* Floating Cards */}
              <div className="absolute top-10 right-[-20px] glass-panel p-4 rounded-2xl animate-bounce" style={{ animationDuration: '3s' }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm font-bold">رعاية آمنة 100%</p>
                    <p className="text-xs text-muted-foreground">أعلى معايير التعقيم</p>
                  </div>
                </div>
              </div>

              <div className="absolute bottom-20 left-[-20px] glass-panel p-4 rounded-2xl animate-bounce" style={{ animationDuration: '4s', animationDelay: '1s' }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-primary">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm font-bold">مواعيد مرنة</p>
                    <p className="text-xs text-muted-foreground">طوال أيام الأسبوع</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-white relative z-20 -mt-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 rounded-3xl shadow-xl shadow-black/5 border border-border/50">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 divide-x divide-x-reverse divide-border/50">
          <div className="text-center">
            <h3 className="text-4xl font-display font-extrabold text-primary mb-2">+15</h3>
            <p className="text-muted-foreground font-medium">سنوات خبرة</p>
          </div>
          <div className="text-center">
            <h3 className="text-4xl font-display font-extrabold text-primary mb-2">+20</h3>
            <p className="text-muted-foreground font-medium">طبيب متخصص</p>
          </div>
          <div className="text-center">
            <h3 className="text-4xl font-display font-extrabold text-primary mb-2">+5K</h3>
            <p className="text-muted-foreground font-medium">مريض سعيد</p>
          </div>
          <div className="text-center">
            <h3 className="text-4xl font-display font-extrabold text-primary mb-2">+50</h3>
            <p className="text-muted-foreground font-medium">جائزة طبية</p>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-tr from-primary/20 to-accent/20 blur-2xl rounded-3xl -z-10"></div>
              <img 
                src={`${import.meta.env.BASE_URL}images/about-image.png`}
                alt="About Clinic" 
                className="w-full rounded-3xl shadow-2xl object-cover h-[500px]"
              />
              <div className="absolute -bottom-8 -right-8 glass-panel p-6 rounded-2xl max-w-[200px]">
                <h4 className="font-bold text-xl text-primary mb-1">الأفضل تقييماً</h4>
                <p className="text-sm text-muted-foreground">حاصلون على أعلى التقييمات في المنطقة</p>
              </div>
            </div>
            
            <div>
              <h2 className="text-primary font-bold text-lg mb-2 flex items-center gap-2">
                <span className="w-8 h-1 bg-primary rounded-full"></span>
                من نحن
              </h2>
              <h3 className="text-3xl md:text-4xl font-display font-bold mb-6 text-foreground">
                رعاية متكاملة لصحة فمك وأسنانك تحت سقف واحد
              </h3>
              <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
                في عيادتنا، نؤمن بأن الابتسامة الجميلة تبدأ بصحة فم ممتازة. نجمع بين أحدث التقنيات العالمية والخبرات الطبية الاستثنائية لنقدم لك علاجاً دقيقاً ومريحاً.
              </p>
              
              <ul className="space-y-4 mb-10">
                {[
                  "أجهزة تشخيص وعلاج متطورة",
                  "أطباء استشاريون في كافة التخصصات",
                  "بيئة معقمة وفق أعلى المعايير",
                  "خطط علاجية مخصصة لكل مريض"
                ].map((item, idx) => (
                  <li key={idx} className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                    <span className="font-medium text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
              
              <Link 
                href="/doctors" 
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold bg-secondary text-secondary-foreground hover:bg-primary hover:text-white transition-all duration-300"
              >
                تعرف على أطبائنا
                <ArrowLeft className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-primary font-bold text-lg mb-2 flex items-center justify-center gap-2">
              <span className="w-8 h-1 bg-primary rounded-full"></span>
              خدماتنا
              <span className="w-8 h-1 bg-primary rounded-full"></span>
            </h2>
            <h3 className="text-3xl md:text-4xl font-display font-bold mb-4 text-foreground">
              حلول متكاملة لابتسامة مثالية
            </h3>
            <p className="text-muted-foreground">
              نقدم مجموعة واسعة من خدمات طب الأسنان التجميلي والعلاجي لتلبية كافة احتياجاتك
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {previewServices.map((service) => (
              <div 
                key={service.id}
                className="bg-background rounded-3xl p-8 border border-border hover:border-primary hover:shadow-2xl hover:shadow-primary/10 transition-all duration-300 group cursor-pointer"
              >
                <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-primary group-hover:text-white transition-all duration-300">
                   <div dangerouslySetInnerHTML={{ __html: service.icon || '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>' }} className="w-8 h-8 [&>svg]:w-full [&>svg]:h-full" />
                </div>
                <h4 className="text-2xl font-bold font-display mb-3 text-foreground">{service.nameAr}</h4>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  {service.descriptionAr.substring(0, 100)}...
                </p>
                <Link href="/services" className="text-primary font-bold inline-flex items-center gap-2 group-hover:gap-3 transition-all">
                  المزيد من التفاصيل
                  <ArrowLeft className="w-4 h-4" />
                </Link>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link 
              href="/services" 
              className="inline-flex items-center justify-center px-8 py-4 rounded-xl font-bold bg-white text-primary border-2 border-primary/20 hover:bg-primary hover:text-white transition-all duration-300 shadow-sm"
            >
              عرض كافة الخدمات
            </Link>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent -z-10"></div>
        <div className="absolute inset-0 bg-[url('https://pixabay.com/get/gdd9489baeffbdfae0898192441016f6543c0fec17e892acbb2f34a630899cf3974e2ea248cfe1253ab468fbb0daaf69c04c5477e415df19b23ade375cb4e4bed_1280.png')] opacity-10 mix-blend-overlay bg-cover bg-center -z-10"></div>
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white relative z-10">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-6">
            هل أنت مستعد للحصول على الابتسامة التي تحلم بها؟
          </h2>
          <p className="text-xl text-white/90 mb-10 max-w-2xl mx-auto">
            احجز موعدك الآن واحصل على استشارة مجانية مع أفضل أطباء الأسنان.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link 
              href="/booking" 
              className="px-8 py-4 rounded-xl font-bold bg-white text-primary hover:bg-gray-50 hover:-translate-y-1 transition-all duration-300 shadow-xl flex items-center justify-center gap-2 text-lg"
            >
              <Calendar className="w-5 h-5" />
              احجز موعدك الآن
            </Link>
            <a 
              href="tel:+966500000000" 
              className="px-8 py-4 rounded-xl font-bold bg-white/20 backdrop-blur-md text-white border border-white/30 hover:bg-white/30 transition-all duration-300 flex items-center justify-center gap-2 text-lg"
            >
              <Phone className="w-5 h-5" />
              <span dir="ltr">+966 50 000 0000</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
