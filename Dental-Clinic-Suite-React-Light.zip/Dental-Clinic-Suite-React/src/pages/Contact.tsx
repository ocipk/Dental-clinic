import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2 } from "lucide-react";
import { useSendContactMessage } from "@workspace/api-client-react";

const contactSchema = z.object({
  name: z.string().min(2, "الاسم مطلوب"),
  email: z.string().email("البريد الإلكتروني غير صحيح"),
  phone: z.string().optional(),
  subject: z.string().min(2, "الموضوع مطلوب"),
  message: z.string().min(10, "الرسالة يجب أن تكون 10 أحرف على الأقل"),
});

type ContactFormValues = z.infer<typeof contactSchema>;

export default function Contact() {
  const [isSuccess, setIsSuccess] = useState(false);
  const { mutateAsync: sendMessage, isPending } = useSendContactMessage();

  const { register, handleSubmit, formState: { errors }, reset } = useForm<ContactFormValues>({
    resolver: zodResolver(contactSchema),
  });

  const onSubmit = async (data: ContactFormValues) => {
    try {
      await sendMessage({ data });
      setIsSuccess(true);
      reset();
      setTimeout(() => setIsSuccess(false), 5000);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="w-full min-h-screen bg-background">
      {/* Header with image bg */}
      <div className="relative pt-24 pb-32 overflow-hidden border-b border-border">
        <div className="absolute inset-0 z-0">
          <img 
            src={`${import.meta.env.BASE_URL}images/contact-bg.png`}
            alt="Contact Background" 
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-white/70 backdrop-blur-sm"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-display font-extrabold text-foreground mb-4">
            تواصل <span className="text-primary">معنا</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto font-medium">
            نحن هنا للإجابة على استفساراتك وتلبية احتياجاتك. لا تتردد في التواصل معنا في أي وقت.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 relative z-20 pb-24">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Contact Info Cards */}
          <div className="lg:col-span-1 flex flex-col gap-6">
            <div className="bg-white rounded-3xl p-8 shadow-xl shadow-black/5 border border-border">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                <MapPin className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold font-display mb-2">موقع العيادة</h3>
              <p className="text-muted-foreground leading-relaxed">
                شارع التحلية، حي العليا،<br />الرياض، المملكة العربية السعودية
              </p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-xl shadow-black/5 border border-border">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                <Phone className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold font-display mb-2">اتصل بنا</h3>
              <p className="text-muted-foreground leading-relaxed mb-1" dir="ltr">+966 50 000 0000</p>
              <p className="text-muted-foreground leading-relaxed" dir="ltr">+966 11 000 0000</p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-xl shadow-black/5 border border-border">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                <Clock className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold font-display mb-2">ساعات العمل</h3>
              <ul className="text-muted-foreground space-y-2">
                <li className="flex justify-between border-b border-border/50 pb-2">
                  <span>السبت - الخميس:</span>
                  <span dir="ltr">09:00 AM - 10:00 PM</span>
                </li>
                <li className="flex justify-between pt-1">
                  <span>الجمعة:</span>
                  <span className="text-primary font-bold">مغلق</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2 bg-white rounded-3xl p-8 md:p-12 shadow-xl shadow-black/5 border border-border">
            <h2 className="text-3xl font-display font-bold mb-8 text-foreground">أرسل رسالة</h2>
            
            {isSuccess ? (
              <div className="bg-green-50 text-green-700 p-8 rounded-2xl border border-green-200 text-center">
                <CheckCircle2 className="w-16 h-16 mx-auto mb-4" />
                <h3 className="text-2xl font-bold mb-2">تم الإرسال بنجاح!</h3>
                <p>شكراً لتواصلك معنا، سنقوم بالرد عليك في أقرب وقت ممكن.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-foreground">الاسم</label>
                    <input 
                      {...register("name")}
                      className="w-full px-4 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all"
                      placeholder="اسمك الكريم"
                    />
                    {errors.name && <p className="text-sm text-destructive">{errors.name.message}</p>}
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-foreground">البريد الإلكتروني</label>
                    <input 
                      {...register("email")}
                      type="email"
                      className="w-full px-4 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all"
                      placeholder="البريد الإلكتروني"
                      dir="ltr"
                    />
                    {errors.email && <p className="text-sm text-destructive">{errors.email.message}</p>}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-foreground">رقم الجوال (اختياري)</label>
                    <input 
                      {...register("phone")}
                      className="w-full px-4 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all"
                      placeholder="رقم الجوال"
                      dir="ltr"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-foreground">الموضوع</label>
                    <input 
                      {...register("subject")}
                      className="w-full px-4 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all"
                      placeholder="عنوان الرسالة"
                    />
                    {errors.subject && <p className="text-sm text-destructive">{errors.subject.message}</p>}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-foreground">الرسالة</label>
                  <textarea 
                    {...register("message")}
                    rows={6}
                    className="w-full px-4 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all resize-none"
                    placeholder="اكتب رسالتك هنا..."
                  />
                  {errors.message && <p className="text-sm text-destructive">{errors.message.message}</p>}
                </div>

                <button
                  type="submit"
                  disabled={isPending}
                  className="w-full md:w-auto px-10 py-4 rounded-xl font-bold bg-primary text-white shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-70 transition-all duration-300 flex items-center justify-center gap-2"
                >
                  {isPending ? "جاري الإرسال..." : (
                    <>
                      إرسال الرسالة
                      <Send className="w-5 h-5 rtl:rotate-180" />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
