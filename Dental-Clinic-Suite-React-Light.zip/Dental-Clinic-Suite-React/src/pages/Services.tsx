import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { useGetServices } from "@workspace/api-client-react";

export default function Services() {
  const { data: services, isLoading } = useGetServices();

  return (
    <div className="w-full bg-background min-h-screen pb-24">
      {/* Page Header */}
      <div className="bg-primary/5 py-16 md:py-24 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-display font-extrabold text-foreground mb-4">
            خدماتنا <span className="text-primary">الطبية</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            مجموعة شاملة من خدمات طب وعلاج الأسنان بأحدث التقنيات والأجهزة الطبية لضمان حصولك على أفضل النتائج.
          </p>
        </div>
      </div>

      {/* Services Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-white rounded-3xl p-8 border border-border animate-pulse h-80">
                <div className="w-16 h-16 bg-muted rounded-2xl mb-6"></div>
                <div className="h-6 bg-muted rounded w-1/2 mb-4"></div>
                <div className="h-4 bg-muted rounded w-full mb-2"></div>
                <div className="h-4 bg-muted rounded w-3/4 mb-6"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services?.map((service, index) => (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                key={service.id}
                className="bg-white rounded-3xl p-8 border border-border hover:border-primary hover:shadow-xl hover:shadow-primary/5 transition-all duration-300 flex flex-col h-full"
              >
                <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                  <div dangerouslySetInnerHTML={{ __html: service.icon || '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>' }} className="w-8 h-8 [&>svg]:w-full [&>svg]:h-full" />
                </div>
                <h3 className="text-2xl font-bold font-display mb-3 text-foreground">{service.nameAr}</h3>
                <p className="text-muted-foreground leading-relaxed mb-6 flex-1">
                  {service.descriptionAr}
                </p>
                <div className="pt-6 border-t border-border mt-auto flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground bg-secondary px-3 py-1 rounded-full">
                    المدة: {service.duration}
                  </span>
                  <Link href={`/booking?service=${service.id}`} className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-colors">
                    <ArrowLeft className="w-5 h-5" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
