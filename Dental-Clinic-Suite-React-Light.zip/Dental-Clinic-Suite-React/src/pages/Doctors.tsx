import { motion } from "framer-motion";
import { Calendar, Award } from "lucide-react";
import { Link } from "wouter";
import { useGetDoctors } from "@workspace/api-client-react";

export default function Doctors() {
  const { data: doctors, isLoading } = useGetDoctors();

  return (
    <div className="w-full bg-background min-h-screen pb-24">
      {/* Page Header */}
      <div className="bg-primary/5 py-16 md:py-24 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-display font-extrabold text-foreground mb-4">
            أطباؤنا <span className="text-primary">المتميزون</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            نفتخر بضم نخبة من أفضل الأطباء والاستشاريين ذوي الخبرة الواسعة لتقديم أعلى مستويات الرعاية.
          </p>
        </div>
      </div>

      {/* Doctors Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-white rounded-3xl p-6 border border-border animate-pulse h-96">
                <div className="w-full h-48 bg-muted rounded-2xl mb-6"></div>
                <div className="h-6 bg-muted rounded w-1/2 mb-4"></div>
                <div className="h-4 bg-muted rounded w-3/4 mb-4"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {doctors?.map((doctor, index) => (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                key={doctor.id}
                className="bg-white rounded-3xl p-6 border border-border hover:shadow-2xl hover:shadow-primary/10 transition-all duration-300 group"
              >
                <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden mb-6 bg-muted">
                  <img 
                    src={`https://ui-avatars.com/api/?name=${encodeURIComponent(doctor.nameAr)}&size=400&background=0ea5e9&color=ffffff&bold=true&font-size=0.35&rounded=false`}
                    alt={doctor.nameAr}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full text-xs font-bold text-primary flex items-center gap-1 shadow-sm">
                    <Award className="w-3.5 h-3.5" />
                    {doctor.yearsExperience} سنة خبرة
                  </div>
                </div>
                
                <h3 className="text-2xl font-bold font-display mb-1 text-foreground">{doctor.nameAr}</h3>
                <p className="text-primary font-medium mb-4">{doctor.specialtyAr}</p>
                <p className="text-muted-foreground text-sm leading-relaxed mb-6 h-20 overflow-hidden line-clamp-3">
                  {doctor.bioAr}
                </p>
                
                <Link 
                  href={`/booking?doctor=${doctor.id}`} 
                  className="w-full py-3.5 rounded-xl font-bold bg-secondary text-foreground hover:bg-primary hover:text-white transition-colors flex items-center justify-center gap-2"
                >
                  <Calendar className="w-4 h-4" />
                  احجز موعد مع الطبيب
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
