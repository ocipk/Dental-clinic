import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Calendar, User, Phone, Mail, Clock, FileText, CheckCircle2 } from "lucide-react";
import { useGetServices, useGetDoctors, useCreateAppointment } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { format, addDays, startOfToday } from "date-fns";

const bookingSchema = z.object({
  patientName: z.string().min(2, "الاسم مطلوب (حرفين على الأقل)"),
  patientPhone: z.string().min(10, "رقم الجوال غير صحيح"),
  patientEmail: z.string().email("البريد الإلكتروني غير صحيح"),
  serviceId: z.coerce.number().min(1, "يرجى اختيار الخدمة"),
  doctorId: z.coerce.number().min(1, "يرجى اختيار الطبيب"),
  appointmentDate: z.string().min(1, "يرجى اختيار تاريخ"),
  appointmentTime: z.string().min(1, "يرجى اختيار وقت"),
  notes: z.string().optional(),
});

type BookingFormValues = z.infer<typeof bookingSchema>;

const timeSlots = [
  "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", 
  "11:00 AM", "11:30 AM", "01:00 PM", "01:30 PM",
  "02:00 PM", "02:30 PM", "03:00 PM", "03:30 PM",
  "04:00 PM", "04:30 PM", "05:00 PM", "05:30 PM"
];

export default function Booking() {
  const { toast } = useToast();
  const [isSuccess, setIsSuccess] = useState(false);
  const { data: services, isLoading: loadingServices } = useGetServices();
  const { data: doctors, isLoading: loadingDoctors } = useGetDoctors();
  const { mutateAsync: createAppointment, isPending } = useCreateAppointment();

  // Generate next 14 days for selection
  const availableDates = Array.from({ length: 14 }).map((_, i) => {
    const d = addDays(startOfToday(), i + 1);
    return {
      value: format(d, 'yyyy-MM-dd'),
      label: new Intl.DateTimeFormat('ar-EG', { weekday: 'short', month: 'short', day: 'numeric' }).format(d)
    };
  });

  const { register, handleSubmit, formState: { errors }, watch, setValue } = useForm<BookingFormValues>({
    resolver: zodResolver(bookingSchema),
  });

  const selectedDate = watch("appointmentDate");
  const selectedTime = watch("appointmentTime");

  useEffect(() => {
    // Check URL params for pre-selected service or doctor
    const params = new URLSearchParams(window.location.search);
    const serviceId = params.get("service");
    const doctorId = params.get("doctor");
    
    if (serviceId) setValue("serviceId", parseInt(serviceId));
    if (doctorId) setValue("doctorId", parseInt(doctorId));
  }, [setValue]);

  const onSubmit = async (data: BookingFormValues) => {
    try {
      await createAppointment({ data });
      setIsSuccess(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء حجز الموعد، يرجى المحاولة مرة أخرى.",
        variant: "destructive"
      });
    }
  };

  if (isSuccess) {
    return (
      <div className="w-full min-h-[80vh] flex items-center justify-center bg-background p-4">
        <div className="bg-white p-10 rounded-3xl shadow-xl max-w-lg w-full text-center border border-border">
          <div className="w-24 h-24 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-12 h-12" />
          </div>
          <h2 className="text-3xl font-display font-bold text-foreground mb-4">تم حجز موعدك بنجاح!</h2>
          <p className="text-muted-foreground mb-8 text-lg">
            تم استلام طلبك وسيقوم فريقنا بالتواصل معك قريباً لتأكيد الموعد النهائي.
          </p>
          <button 
            onClick={() => window.location.href = '/'}
            className="w-full py-4 rounded-xl font-bold bg-primary text-white hover:bg-primary/90 transition-colors"
          >
            العودة للرئيسية
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full bg-background min-h-screen py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-display font-extrabold text-foreground mb-4">
            احجز <span className="text-primary">موعدك</span>
          </h1>
          <p className="text-lg text-muted-foreground">
            قم بملء النموذج التالي لحجز موعدك في العيادة، وسنؤكد لك الموعد في أقرب وقت.
          </p>
        </div>

        <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl shadow-black/5 border border-border">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
            
            {/* Personal Info */}
            <div>
              <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2 border-b border-border pb-4">
                <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">1</span>
                المعلومات الشخصية
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-foreground block">الاسم الكامل</label>
                  <div className="relative">
                    <User className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <input 
                      {...register("patientName")}
                      className="w-full pl-4 pr-12 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all"
                      placeholder="أدخل اسمك الكامل"
                    />
                  </div>
                  {errors.patientName && <p className="text-sm text-destructive">{errors.patientName.message}</p>}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-foreground block">رقم الجوال</label>
                  <div className="relative">
                    <Phone className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <input 
                      {...register("patientPhone")}
                      className="w-full pl-4 pr-12 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all"
                      placeholder="05x xxx xxxx"
                      dir="ltr"
                    />
                  </div>
                  {errors.patientPhone && <p className="text-sm text-destructive">{errors.patientPhone.message}</p>}
                </div>

                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-bold text-foreground block">البريد الإلكتروني</label>
                  <div className="relative">
                    <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <input 
                      {...register("patientEmail")}
                      type="email"
                      className="w-full pl-4 pr-12 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all"
                      placeholder="example@email.com"
                      dir="ltr"
                    />
                  </div>
                  {errors.patientEmail && <p className="text-sm text-destructive">{errors.patientEmail.message}</p>}
                </div>
              </div>
            </div>

            {/* Service & Doctor */}
            <div>
              <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2 border-b border-border pb-4">
                <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">2</span>
                الخدمة والطبيب
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-foreground block">الخدمة المطلوبة</label>
                  <select 
                    {...register("serviceId")}
                    className="w-full px-4 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all appearance-none cursor-pointer"
                    disabled={loadingServices}
                  >
                    <option value="">اختر الخدمة</option>
                    {services?.map(s => (
                      <option key={s.id} value={s.id}>{s.nameAr}</option>
                    ))}
                  </select>
                  {errors.serviceId && <p className="text-sm text-destructive">{errors.serviceId.message}</p>}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-foreground block">الطبيب (اختياري)</label>
                  <select 
                    {...register("doctorId")}
                    className="w-full px-4 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all appearance-none cursor-pointer"
                    disabled={loadingDoctors}
                  >
                    <option value="">أي طبيب متاح</option>
                    {doctors?.map(d => (
                      <option key={d.id} value={d.id}>د. {d.nameAr} - {d.specialtyAr}</option>
                    ))}
                  </select>
                  {errors.doctorId && <p className="text-sm text-destructive">{errors.doctorId.message}</p>}
                </div>
              </div>
            </div>

            {/* Date & Time */}
            <div>
              <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2 border-b border-border pb-4">
                <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">3</span>
                تاريخ ووقت الموعد
              </h3>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-foreground block mb-3">اختر اليوم</label>
                  <div className="flex overflow-x-auto pb-4 gap-3 snap-x hide-scrollbar">
                    {availableDates.map(date => (
                      <button
                        type="button"
                        key={date.value}
                        onClick={() => setValue("appointmentDate", date.value, { shouldValidate: true })}
                        className={`shrink-0 snap-center w-24 py-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-1 ${
                          selectedDate === date.value 
                            ? "border-primary bg-primary/5 text-primary shadow-sm" 
                            : "border-border bg-background hover:border-primary/30 text-muted-foreground"
                        }`}
                      >
                        <Calendar className="w-5 h-5 mb-1" />
                        <span className="text-xs font-bold whitespace-nowrap">{date.label}</span>
                      </button>
                    ))}
                  </div>
                  {errors.appointmentDate && <p className="text-sm text-destructive">{errors.appointmentDate.message}</p>}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-foreground block mb-3">اختر الوقت</label>
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-8 gap-3">
                    {timeSlots.map(time => (
                      <button
                        type="button"
                        key={time}
                        onClick={() => setValue("appointmentTime", time, { shouldValidate: true })}
                        className={`py-2.5 rounded-xl border-2 transition-all text-sm font-bold ${
                          selectedTime === time
                            ? "border-primary bg-primary/5 text-primary shadow-sm"
                            : "border-border bg-background hover:border-primary/30 text-muted-foreground"
                        }`}
                        dir="ltr"
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                  {errors.appointmentTime && <p className="text-sm text-destructive">{errors.appointmentTime.message}</p>}
                </div>
              </div>
            </div>

            {/* Notes */}
            <div>
              <h3 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2 border-b border-border pb-4">
                <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">4</span>
                ملاحظات إضافية
              </h3>
              <div className="space-y-2">
                <div className="relative">
                  <FileText className="absolute right-4 top-4 w-5 h-5 text-muted-foreground" />
                  <textarea 
                    {...register("notes")}
                    rows={4}
                    className="w-full pl-4 pr-12 py-3.5 rounded-xl bg-background border-2 border-border focus:border-primary focus:ring-4 focus:ring-primary/10 outline-none transition-all resize-none"
                    placeholder="هل لديك أي ملاحظات أو أسئلة للطبيب؟ (اختياري)"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={isPending}
              className="w-full py-5 rounded-2xl font-bold text-lg bg-gradient-to-r from-primary to-primary/90 text-white shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed transition-all duration-300"
            >
              {isPending ? "جاري تأكيد الحجز..." : "تأكيد الحجز"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
