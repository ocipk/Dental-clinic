import { Link } from "wouter";
import { Stethoscope, MapPin, Phone, Mail, Instagram, Twitter, Facebook } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-foreground text-white/80 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand */}
          <div className="space-y-6">
            <Link href="/" className="flex items-center gap-2 group inline-flex">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white shadow-lg">
                <Stethoscope className="w-7 h-7" />
              </div>
              <span className="font-display font-bold text-2xl text-white">
                ابتسامة <span className="text-primary">مشرقة</span>
              </span>
            </Link>
            <p className="text-white/60 leading-relaxed max-w-xs">
              نقدم رعاية أسنان متطورة بأحدث التقنيات وأفضل الكوادر الطبية لضمان ابتسامة صحية وجذابة تدوم طويلاً.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-primary hover:text-white transition-all">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-primary hover:text-white transition-all">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-primary hover:text-white transition-all">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-display font-bold text-lg mb-6 relative inline-block">
              روابط سريعة
              <span className="absolute -bottom-2 right-0 w-1/2 h-1 bg-primary rounded-full"></span>
            </h3>
            <ul className="space-y-4">
              <li><Link href="/" className="hover:text-primary transition-colors flex items-center gap-2 before:content-[''] before:w-1.5 before:h-1.5 before:bg-primary before:rounded-full">الرئيسية</Link></li>
              <li><Link href="/services" className="hover:text-primary transition-colors flex items-center gap-2 before:content-[''] before:w-1.5 before:h-1.5 before:bg-primary before:rounded-full">خدماتنا</Link></li>
              <li><Link href="/doctors" className="hover:text-primary transition-colors flex items-center gap-2 before:content-[''] before:w-1.5 before:h-1.5 before:bg-primary before:rounded-full">أطباؤنا</Link></li>
              <li><Link href="/booking" className="hover:text-primary transition-colors flex items-center gap-2 before:content-[''] before:w-1.5 before:h-1.5 before:bg-primary before:rounded-full">احجز موعد</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-white font-display font-bold text-lg mb-6 relative inline-block">
              أبرز خدماتنا
              <span className="absolute -bottom-2 right-0 w-1/2 h-1 bg-primary rounded-full"></span>
            </h3>
            <ul className="space-y-4">
              <li><Link href="/services" className="hover:text-primary transition-colors">زراعة الأسنان</Link></li>
              <li><Link href="/services" className="hover:text-primary transition-colors">تقويم الأسنان الشفاف</Link></li>
              <li><Link href="/services" className="hover:text-primary transition-colors">تبييض الأسنان بالليزر</Link></li>
              <li><Link href="/services" className="hover:text-primary transition-colors">ابتسامة هوليود</Link></li>
              <li><Link href="/services" className="hover:text-primary transition-colors">علاج العصب والجذور</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-display font-bold text-lg mb-6 relative inline-block">
              معلومات التواصل
              <span className="absolute -bottom-2 right-0 w-1/2 h-1 bg-primary rounded-full"></span>
            </h3>
            <ul className="space-y-6">
              <li className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center shrink-0 text-primary">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-white mb-1">العنوان</p>
                  <p className="text-sm text-white/60">شارع التحلية، حي العليا، الرياض، المملكة العربية السعودية</p>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center shrink-0 text-primary">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-white mb-1">الهاتف</p>
                  <p className="text-sm text-white/60" dir="ltr">+966 50 000 0000</p>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center shrink-0 text-primary">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-bold text-white mb-1">البريد الإلكتروني</p>
                  <p className="text-sm text-white/60">info@brightsmile.com</p>
                </div>
              </li>
            </ul>
          </div>

        </div>
        
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-white/50">
            جميع الحقوق محفوظة © {new Date().getFullYear()} عيادة ابتسامة مشرقة.
          </p>
          <div className="flex gap-6 text-sm text-white/50">
            <a href="#" className="hover:text-white transition-colors">الشروط والأحكام</a>
            <a href="#" className="hover:text-white transition-colors">سياسة الخصوصية</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
